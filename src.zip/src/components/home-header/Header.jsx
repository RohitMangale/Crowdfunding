import React from 'react'
import './Header.css'

import headerImg from '../../assets/imgs/office.png'
import open from '../../assets/imgs/perplexity.jpg'

const Header = () => {
    return (
        <div className='header container'>
        <div className="h-left">
            <p className="subHeading">Help poor families</p>
            <p className="mainHeading">Give Hope, change lives, spread love. </p>
            <p className="para">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto illum modi ab assumenda saepe eveniet doloribus  </p>
            <div className="headerCon">
                <button className="btn">Fund Now</button>

            </div>
        </div>
        <div className="h-right">
            <img src={headerImg} alt="headerImg" />
        </div>
    </div>

    )
}

export default Header
