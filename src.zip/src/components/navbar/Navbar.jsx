// import React from 'react'
// import './Navbar.css'
// import navlogo  from "../../assets/imgs/logo.png";



// const Navbar = () => {
//     return (
//         <div className='navbar'>
//         <div className="container navbar">
//             <div className="logoImg">
//             <img src={navlogo} alt="" />
//             </div>
//             <div className="navLinks">
//                 <a href="">Home</a>
//                 <a href="">About</a>
//                 <a href="">Campaigns</a>
//                 <a href="">Startups</a>
//                 <a href="">Pages</a>
//             </div>

//             <div className="appLinks">
//                 <button className='btn1 navbtn' href="">Sign Up</button>
//             </div>
//         </div>

//         </div>
//     )
// }

// export default Navbar
