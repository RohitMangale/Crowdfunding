import React from 'react'
import './Banner.css'
import crowd from '../../assets/imgs/crowdfunsing.jpg'
const Banner = () => {
  return (
    <div className="dgca-maindiv container">

    <div className="dgca-onediv">
        <p className='subHeading' >EazzyFunzz</p>
        <h1 >Invest in Innovation!</h1>
        <p className='para' >
        Explore groundbreaking ideas. Connect visionaries with investors. Fuel innovation and growth.  
        </p>
        <button href='https://www.dgca.gov.in/digigov-portal/' target='_blank' className='btn' >Join Now</button>
    </div>

    <div className="dgca-twodiv">
    </div>
</div>
  )
}

export default Banner
